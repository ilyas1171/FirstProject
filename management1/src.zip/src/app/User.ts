export class User {
    userName: any
    userPassword:any
}
