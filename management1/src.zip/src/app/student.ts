export class Student {
    id:any;
    firstName:any;
    lastName:any;
    email:any;
    age:any;
}

